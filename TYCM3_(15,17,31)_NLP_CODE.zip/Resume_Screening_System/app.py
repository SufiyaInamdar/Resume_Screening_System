import streamlit as st
import pandas as pd
import joblib
from sklearn.metrics.pairwise import cosine_similarity
from src.preprocessing import clean_resume
from src.parser import extract_text_from_file

# Page Layout Config
st.set_page_config(page_title="AI Resume Screening System", page_icon="📄", layout="wide")

# Load pre-trained models
@st.cache_resource
def load_models():
    tfidf = joblib.load('models/tfidf_vectorizer.pkl')
    classifier = joblib.load('models/resume_classifier.pkl')
    label_encoder = joblib.load('models/label_encoder.pkl')
    return tfidf, classifier, label_encoder

try:
    tfidf, classifier, label_encoder = load_models()
except Exception as e:
    st.error("Error loading model artifacts. Please ensure 'python src/train.py' has been executed.")
    st.stop()

# Header Section
st.title("📄 AI-Powered Resume Screening & Job Matching System")
st.markdown("""
*Automated NLP pipeline for candidate evaluation, category classification, and job description semantic matching.*
""")

# Navigation Tabs
tab1, tab2, tab3 = st.tabs(["🎯 Candidate-Job Matcher", "🏷️ Resume Category Predictor", "📊 Dataset Analytics"])

# ------------------------------------------------------------------------------
# TAB 1: CANDIDATE - JOB MATCHING ENGINE
# ------------------------------------------------------------------------------
with tab1:
    st.subheader("Candidate Shortlisting & Similarity Ranking")
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        job_description = st.text_area("Paste Target Job Description (JD):", height=220, placeholder="Enter key skills, responsibilities, and requirements...")
        
    with col2:
        uploaded_files = st.file_uploader("Upload Candidate Resumes (PDF, DOCX, TXT):", type=["pdf", "docx", "txt"], accept_multiple_files=True)
        
    if st.button("Run Candidate Screening", type="primary"):
        if not job_description.strip():
            st.warning("Please provide a valid Job Description.")
        elif not uploaded_files:
            st.warning("Please upload at least one candidate resume.")
        else:
            with st.spinner("Processing resumes through NLP pipeline..."):
                cleaned_jd = clean_resume(job_description)
                jd_vector = tfidf.transform([cleaned_jd])
                
                results = []
                
                for file in uploaded_files:
                    raw_text = extract_text_from_file(file)
                    cleaned_resume = clean_resume(raw_text)
                    resume_vector = tfidf.transform([cleaned_resume])
                    
                    # Compute Cosine Similarity
                    similarity_score = cosine_similarity(jd_vector, resume_vector)[0][0]
                    fit_percentage = round(similarity_score * 100, 2)
                    
                    # Predict Category
                    category_code = classifier.predict(resume_vector)[0]
                    predicted_category = label_encoder.inverse_transform([category_code])[0]
                    
                    results.append({
                        "Candidate File": file.name,
                        "Fit Score (%)": fit_percentage,
                        "Predicted Job Category": predicted_category,
                        "Status": "Shortlisted" if fit_percentage >= 50.0 else "Under Review"
                    })
                
                # Display Summary Dashboard Table
                results_df = pd.DataFrame(results).sort_values(by="Fit Score (%)", ascending=False)
                
                st.success(f"Screened {len(uploaded_files)} candidate resumes successfully!")
                
                # Display Metric Cards
                top_candidate = results_df.iloc[0]
                m_col1, m_col2, m_col3 = st.columns(3)
                m_col1.metric("Total Applicants", len(uploaded_files))
                m_col2.metric("Top Candidate Score", f"{top_candidate['Fit Score (%)']}%")
                m_col3.metric("Shortlisted Candidates", len(results_df[results_df['Fit Score (%)'] >= 50.0]))
                
                st.markdown("### 🏆 Candidate Ranking Board")
                st.dataframe(results_df, use_container_width=True)

# ------------------------------------------------------------------------------
# TAB 2: RESUME CATEGORY PREDICTOR
# ------------------------------------------------------------------------------
with tab2:
    st.subheader("Single Resume Auto-Classification")
    
    single_file = st.file_uploader("Upload a Single Resume for Domain Classification:", type=["pdf", "docx", "txt"], key="single_upload")
    raw_resume_input = st.text_area("Or Paste Resume Text directly:", height=150)
    
    if st.button("Classify Resume Category"):
        resume_text = ""
        if single_file is not None:
            resume_text = extract_text_from_file(single_file)
        elif raw_resume_input.strip():
            resume_text = raw_resume_input
            
        if not resume_text.strip():
            st.error("Please upload a file or paste text to classify.")
        else:
            cleaned_text = clean_resume(resume_text)
            vector = tfidf.transform([cleaned_text])
            
            # Prediction and Probabilities
            pred_code = classifier.predict(vector)[0]
            pred_category = label_encoder.inverse_transform([pred_code])[0]
            probabilities = classifier.predict_proba(vector)[0]
            
            st.success(f"Predicted Job Category: **{pred_category}**")
            
            # Confidence Chart
            prob_df = pd.DataFrame({
                "Category": label_encoder.classes_,
                "Confidence Score": probabilities
            }).sort_values(by="Confidence Score", ascending=False).head(5)
            
            st.markdown("#### Top Category Confidence Probabilities")
            st.bar_chart(prob_df.set_index("Category"))

# ------------------------------------------------------------------------------
# TAB 3: DATASET INSIGHTS
# ------------------------------------------------------------------------------
with tab3:
    st.subheader("System Dataset & Class Distribution")
    st.markdown("Overview of the 962 Kaggle Resumes distribution across 25 Job Categories (Section 4.5).")
    try:
        df_raw = pd.read_csv('data/UpdatedResumeDataSet.csv')
        category_counts = df_raw['Category'].value_counts()
        st.bar_chart(category_counts)
    except FileNotFoundError:
        st.warning("Dataset file `data/UpdatedResumeDataSet.csv` not found.")