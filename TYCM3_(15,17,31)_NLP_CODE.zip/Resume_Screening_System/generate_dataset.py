import os
import random
import pandas as pd

# Create output directory
os.makedirs('data', exist_ok=True)

# Synthetic resume content mapped to project categories
categories_data = {
    "Data Science": [
        "Data Scientist proficient in Python, R, Machine Learning, Scikit-Learn, TensorFlow, SQL, and data visualization using Tableau. Strong background in predictive modeling, NLP, and EDA.",
        "Data Science professional with expertise in Python, Deep Learning, Pandas, NumPy, statistical analysis, and PySpark. Proven track record in building multi-class text classification models.",
        "Machine Learning Engineer skilled in Python, SQL, NLP feature extraction, TF-IDF vectorization, neural networks, and model deployment. Experienced in exploratory data analysis."
    ],
    "Java Developer": [
        "Software Engineer specializing in Java, Spring Boot, Microservices, RESTful APIs, Hibernate, Maven, and SQL databases. Strong experience in enterprise backend development.",
        "Java Developer with hands-on experience in Core Java, J2EE, Spring MVC, PostgreSQL, Git, and Docker. Track record of building scalable web applications.",
        "Senior Backend Developer proficient in Java, Spring Framework, MySQL, Multi-threading, Kafka, and microservice architectures."
    ],
    "HR": [
        "Human Resources Generalist skilled in recruitment, talent acquisition, onboarding, payroll management, employee engagement, and HR policy administration.",
        "HR Manager with expertise in candidate shortlisting, interviewing, performance appraisal systems, strategic HR management, and labor compliance.",
        "Talent Acquisition Specialist with proven background in sourcing candidates, resume screening, talent management, and employee relations."
    ],
    "Testing": [
        "QA Automation Engineer skilled in Selenium, Java, TestNG, JUnit, REST Assured, Cucumber, API testing, and manual testing techniques.",
        "Software Test Engineer proficient in manual testing, bug tracking via Jira, regression testing, automated UI testing, and CI/CD integration.",
        "Quality Analyst with expertise in black-box testing, performance evaluation, Selenium WebDriver, Python testing frameworks, and defect management."
    ],
    "DevOps Engineer": [
        "DevOps Specialist proficient in Docker, Kubernetes, Jenkins, CI/CD pipeline automation, AWS cloud architecture, Terraform, and Linux administration.",
        "Infrastructure Engineer with experience in Ansible, Git, Shell scripting, Prometheus, Grafana, and cloud deployment on Microsoft Azure.",
        "Cloud Engineer specializing in infrastructure as code, AWS services, Kubernetes cluster management, Docker containerization, and deployment automation."
    ],
    "Advocate": [
        "Legal Counsel and Advocate experienced in corporate law, litigation, legal drafting, regulatory compliance, contract negotiation, and dispute resolution.",
        "Legal Advisor proficient in drafting legal contracts, courtroom representation, civil litigation, property law, and regulatory compliance management."
    ]
}

records = []
# Generate multi-sample dataset to enable stratified train-test splitting
for category, templates in categories_data.items():
    for i in range(20):  # 20 records per category = 120 total dataset records
        base_text = random.choice(templates)
        full_text = f"Candidate Profile {i+1}: {base_text} Proficient in Agile methodologies, cross-functional teamwork, and technical documentation."
        records.append({"Category": category, "Resume": full_text})

df = pd.DataFrame(records)
file_path = 'data/UpdatedResumeDataSet.csv'
df.to_csv(file_path, index=False)

print(f"Dataset successfully generated at '{file_path}' with {len(df)} records across {df['Category'].nunique()} categories.")