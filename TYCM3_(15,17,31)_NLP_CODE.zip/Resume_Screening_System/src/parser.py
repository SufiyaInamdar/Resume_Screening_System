from pypdf import PdfReader
import docx

def extract_text_from_file(uploaded_file) -> str:
    """Extracts raw text from PDF, DOCX, or TXT file uploads."""
    filename = uploaded_file.name
    extracted_text = ""
    
    if filename.endswith(".pdf"):
        reader = PdfReader(uploaded_file)
        for page in reader.pages:
            text = page.extract_text()
            if text:
                extracted_text += text + "\n"
                
    elif filename.endswith(".docx"):
        doc = docx.Document(uploaded_file)
        for para in doc.paragraphs:
            extracted_text += para.text + "\n"
            
    elif filename.endswith(".txt"):
        extracted_text = uploaded_file.read().decode("utf-8")
        
    return extracted_text.strip()