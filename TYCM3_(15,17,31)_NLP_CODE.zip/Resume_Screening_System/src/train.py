import os
import sys
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score

# Set base project directory dynamically
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.append(os.path.join(BASE_DIR, 'src'))

from preprocessing import clean_resume

def train_and_save_model():
    data_path = os.path.join(BASE_DIR, 'data', 'UpdatedResumeDataSet.csv')
    model_dir = os.path.join(BASE_DIR, 'models')
    os.makedirs(model_dir, exist_ok=True)
    
    if not os.path.exists(data_path):
        raise FileNotFoundError(f"Dataset missing at {data_path}. Run 'python generate_dataset.py' first.")

    print(f"Loading dataset from: {data_path}")
    df = pd.read_csv(data_path)
    
    print("Cleaning resume text...")
    df['Cleaned_Resume'] = df['Resume'].apply(clean_resume)
    
    # Encode categories
    label_encoder = LabelEncoder()
    df['Category_Encoded'] = label_encoder.fit_transform(df['Category'])
    
    # Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        df['Cleaned_Resume'], 
        df['Category_Encoded'], 
        test_size=0.2, 
        random_state=42, 
        stratify=df['Category_Encoded']
    )
    
    # TF-IDF Feature Extraction
    print("Extracting TF-IDF features...")
    tfidf = TfidfVectorizer(max_features=3000, ngram_range=(1, 2))
    X_train_tfidf = tfidf.fit_transform(X_train)
    X_test_tfidf = tfidf.transform(X_test)
    
    # Classifier Training
    print("Training Logistic Regression classifier...")
    classifier = LogisticRegression(max_iter=1000, class_weight='balanced', random_state=42)
    classifier.fit(X_train_tfidf, y_train)
    
    # Performance Evaluation
    y_pred = classifier.predict(X_test_tfidf)
    acc = accuracy_score(y_test, y_pred)
    print(f"\nModel Accuracy: {acc * 100:.2f}%\n")
    print(classification_report(y_test, y_pred, target_names=label_encoder.classes_))
    
    # Save artifacts to models folder
    joblib.dump(tfidf, os.path.join(model_dir, 'tfidf_vectorizer.pkl'))
    joblib.dump(classifier, os.path.join(model_dir, 'resume_classifier.pkl'))
    joblib.dump(label_encoder, os.path.join(model_dir, 'label_encoder.pkl'))
    print("All artifacts successfully saved in 'models/' folder!")

if __name__ == "__main__":
    train_and_save_model()