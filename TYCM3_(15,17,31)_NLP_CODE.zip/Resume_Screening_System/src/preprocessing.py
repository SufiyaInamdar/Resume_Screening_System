import re
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer

# Download required NLTK resources
nltk.download('stopwords', quiet=True)
nltk.download('wordnet', quiet=True)

stop_words = set(stopwords.words('english'))
lemmatizer = WordNetLemmatizer()

def clean_resume(text: str) -> str:
    """
    Applies regex cleaning, stopword removal, and WordNet lemmatization.
    Matches Section 4.1 - 4.4 specs.
    """
    if not isinstance(text, str):
        return ""
    
    # Lowercasing
    text = text.lower()
    
    # Remove URLs, HTML markup, and emails
    text = re.sub(r'http\S+\s*', ' ', text)
    text = re.sub(r'<[^>]*>', ' ', text)
    text = re.sub(r'\S+@\S+', ' ', text)
    
    # Remove RT/CC and hashtags
    text = re.sub(r'\b(rt|cc)\b', ' ', text)
    text = re.sub(r'#\S+', ' ', text)
    
    # Remove special characters, punctuations, and non-ASCII chars
    text = re.sub(r'[^\w\s]', ' ', text)
    text = re.sub(r'[^\x00-\x7f]', r' ', text)
    
    # Remove extra spaces and digits
    text = re.sub(r'\d+', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()
    
    # Tokenization, Stopword Removal & Lemmatization
    tokens = text.split()
    cleaned_tokens = [
        lemmatizer.lemmatize(word) 
        for word in tokens 
        if word not in stop_words and len(word) > 1
    ]
    
    return " ".join(cleaned_tokens)